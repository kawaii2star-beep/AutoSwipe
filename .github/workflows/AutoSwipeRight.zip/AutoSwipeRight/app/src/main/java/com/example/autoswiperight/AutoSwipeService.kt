package com.example.autoswiperight

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Performs repeated left-to-right swipes while running. It does nothing else:
 * it does not read screen content and does not interact with any other element.
 */
class AutoSwipeService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val swipeRunnable = Runnable { performSwipe() }

    private var running = false

    // Incremented on every stop so late callbacks from an old gesture are ignored.
    private var session = 0

    private val prefs: SharedPreferences by lazy {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        notifyStateChanged()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty: no events are consumed.
    }

    override fun onInterrupt() {
        stopSwiping()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopSwiping()
        if (instance === this) instance = null
        notifyStateChanged()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopSwiping()
        if (instance === this) instance = null
        notifyStateChanged()
        super.onDestroy()
    }

    fun isRunning(): Boolean = running

    fun startSwiping() {
        if (running) return
        running = true
        notifyStateChanged()
        handler.post(swipeRunnable)
    }

    fun stopSwiping() {
        val wasRunning = running
        running = false
        session++
        handler.removeCallbacksAndMessages(null)
        if (wasRunning) notifyStateChanged()
    }

    private fun performSwipe() {
        if (!running) return

        val (width, height) = screenSize()
        val duration = prefs.getInt(KEY_DURATION_MS, DEFAULT_DURATION_MS)
            .coerceIn(MIN_DURATION_MS, MAX_DURATION_MS).toLong()

        val path = Path().apply {
            moveTo(width * START_X_FRACTION, height * Y_FRACTION)
            lineTo(width * END_X_FRACTION, height * Y_FRACTION)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, duration))
            .build()

        val mySession = session
        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                scheduleNext(mySession)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                scheduleNext(mySession)
            }
        }

        val dispatched = dispatchGesture(gesture, callback, handler)
        if (!dispatched) stopSwiping()
    }

    private fun scheduleNext(forSession: Int) {
        if (!running || forSession != session) return
        val interval = prefs.getInt(KEY_INTERVAL_MS, DEFAULT_INTERVAL_MS)
            .coerceIn(MIN_INTERVAL_MS, MAX_INTERVAL_MS).toLong()
        handler.removeCallbacks(swipeRunnable)
        handler.postDelayed(swipeRunnable, interval)
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun notifyStateChanged() {
        onStateChanged?.invoke()
    }

    companion object {
        const val PREFS_NAME = "auto_swipe_prefs"
        const val KEY_INTERVAL_MS = "interval_ms"
        const val KEY_DURATION_MS = "duration_ms"

        const val MIN_INTERVAL_MS = 500
        const val MAX_INTERVAL_MS = 20_000
        const val DEFAULT_INTERVAL_MS = 3_000

        const val MIN_DURATION_MS = 100
        const val MAX_DURATION_MS = 2_000
        const val DEFAULT_DURATION_MS = 350

        private const val START_X_FRACTION = 0.45f
        private const val END_X_FRACTION = 0.92f
        private const val Y_FRACTION = 0.50f

        /** The connected service, or null when it is not enabled/connected. */
        @Volatile
        var instance: AutoSwipeService? = null
            private set

        /** Set by the UI while visible (and cleared when hidden) to avoid leaking the Activity. */
        @Volatile
        var onStateChanged: (() -> Unit)? = null
    }
}
